def total(items):
    return sum(i['amount'] for i in items)
