import os

import stripe

stripe.api_key = os.environ["STRIPE_API_KEY"]
GITHUB_DEPLOY_TOKEN = os.environ.get("GITHUB_DEPLOY_TOKEN", "")

def charge(amount):
    return stripe.Charge.create(amount=amount, currency='usd')
